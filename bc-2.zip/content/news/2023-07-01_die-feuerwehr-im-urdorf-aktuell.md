---
title: Die Feuerwehr im Urdorf Aktuell
description: Die Feuerwehr Urdorf wird im "Urdorf Aktuell", Ausgabe Juni 2023 vorgestellt.
slug: urdorf-aktuell-juni23
date: 2023-07-01T10:00:00.000Z
years:
  - "2023"
---
Die Feuerwehr Urdorf wird im “Urdorf Aktuell” in der [Ausgabe vom Juni 2023](https://www.urdorf.ch/_docn/4510532/Urdorf_aktuell_Juni_2023_Web_Version.pdf) vorgestellt.

![Urdorf Aktuell Juni 2023](urdorf-aktuell-juni-2023.png)