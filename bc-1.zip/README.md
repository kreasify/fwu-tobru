# How to Run this Site?

## Run Site in local machine

Direct terminal to site folder `feuerwehr`

install all node dependency with `npm install` or `yarn install` on terminal

Run hugo site with `hugo server` or `npm run dev`

## Host on Netlify

read documentation here [docs](https://gohugo.io/hosting-and-deployment/hosting-on-netlify/)