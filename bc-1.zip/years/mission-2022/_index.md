---
title: "Einsätze 2022"
description: "Einsätze 2022"
slug: "mission-2022"
page_section: "mission"
page_header:
  enable: true
  page_section: "mission"
  title: "Einsätze"
  subtitle: "2022"
  image_bg: "assets/images/term-news-header-bg.png"
  image: "assets/images/home-section-1-hotline.png"
---
