---
title: "2022"
description: "2022"
slug: "2022"
page_section: "news"
page_header:
  enable: true
  page_section: "news"
  title: "NEWS"
  subtitle: "2022"
  image_bg: "assets/images/term-news-header-bg.png"
  image: "assets/images/home-section-1-hotline.png"
---
