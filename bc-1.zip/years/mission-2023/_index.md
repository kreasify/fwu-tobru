---
title: "Einsätze 2023"
description: "Einsätze 2023"
slug: "mission-2023"
page_section: "mission"
page_header:
  enable: true
  page_section: "mission"
  title: "Einsätze"
  subtitle: "2023"
  image_bg: "assets/images/term-news-header-bg.png"
  image: "assets/images/home-section-1-hotline.png"
---
