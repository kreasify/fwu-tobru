---
title: "2024"
description: "2024"
slug: "2024"
page_section: "news"
page_header:
  enable: true
  page_section: "news"
  title: "NEWS"
  subtitle: "2024"
  image_bg: "assets/images/term-news-header-bg.png"
  image: "assets/images/home-section-1-hotline.png"
---
