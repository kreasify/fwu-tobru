---
title: "Einsätze 2024"
description: "Einsätze 2024"
slug: "mission-2024"
page_section: "mission"
page_header:
  enable: true
  page_section: "mission"
  title: "Einsätze"
  subtitle: "2024"
  image_bg: "assets/images/term-news-header-bg.png"
  image: "assets/images/home-section-1-hotline.png"
---
