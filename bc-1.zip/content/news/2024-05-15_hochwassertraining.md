---
title: Hochwassertraining
description: Die Feuerwehr Urdorf absolvierte am 4. Mai 2024 ein Hochwassertraining in Wangen a.A.
slug: hochwassertraining-2024
date: 2024-05-15T10:00:00.000Z
years:
  - "2024"
---
Die Feuerwehr Urdorf absolvierte am Samstag Vormittag, 4. Mai 2024 ein Hochwassertraining in Wangen an der Aare. Dabei ging es um den korrekten Einsatz der neu angeschafften Watergate-Sperren. Vorort waren unter anderen der Erfinder dieser Watergate-Sperren.

Ein Fernseh-Team von Telebärn hat uns dabei begleitet:

{{< youtube h9d22QhJNN4 >}}
