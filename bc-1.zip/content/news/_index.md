---
title: News
description: News
sections:
- template: page-header-section
  enable: true
  title: "NEWS"
  image_bg: "assets/images/news-section-1-bg.png"
  image: "assets/images/home-section-1-hotline.png"
- template: news-slider-section
  enable: true
layout: page-builder
---
