---
title: "BRK News: Auto stürzt in Tobel"
description: Ein Auto stürzt ins Bachtobel.
slug: auto-absturz
date: 2022-06-30T10:00:00.000Z
years:
  - "2022"
---

Beitrag von [BRK News](https://www.brknews.ch/):

> Urdorf ZH: Auto stürzt in Tobel
> 
> Ein in der Nacht als vermisst gemeldeter Mann ist am Donnerstagmorgen (30.06.2022) tot aufgefunden worden. Kurz vor 8:30 Uhr wurde der Einsatzzentrale gemeldet, dass in einem Tobel ein Fahrzeug liegen würde. Die ausgerückten Rettungskräfte fanden das Fahrzeug rund zwanzig Meter unterhalb der Strasse mit einem leblosen Mann darin. Abklärungen ergaben, dass es sich beim Verstorbenen um den als vermisst gemeldeten 62-jährigen Mann handelt. Nach ersten Ermittlungen war dieser mit seinem Auto von Urdorf in Richtung Birmensdorf unterwegs. Ausgangs einer leichten Rechtskurve geriet das Fahrzeug aus bislang unbekannten Gründen über die Gegenfahrbahn auf das Trottoir. Anschliessend durchschlug es einen Holzzaun und stürzte in das angrenzende Tobel. Während der Unfallaufnahme musste das Fahrzeug von der Feuerwehr mit Spezialwerkzeugen gegen weiteres Abrutschen gesichert werden. Der betroffene Teil der Birmensdorferstrasse wurde für mehrere Stunden beidseitig gesperrt.

{{< youtube nIF-sJdkx1U >}}
