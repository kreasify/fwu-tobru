---
title: Nacht der offenen Tore 2024
description: Nacht der offenen Tore 2024 am 23. August ab 18:00 Uhr
slug: ndot24
date: 2024-06-15T17:00:00.000Z
years:
  - "2024"
image_cover: assets/images/ndot-news-card.png
---
**18:00 - 20:00 Uhr**

Kinderspiele, Fahrzeugausstellung Feuerwehr und Polizei, historische Gerätschaften, Feuerlöschtraining, Einsatzdemonstration

**18:00 - 21:00 Uhr**

Festwirtschaft mit Grill

**21:00 - 02:00 Uhr**

Barbetrieb

![Nacht der offenen Tore 2024 Flyer](a4_nachtderoffenentore_2024-1.png)
