---
title: "BRK News: Brand Dorfstrasse"
description: Ein Feuer an der Dorfstrasse richtet grossen Schaden an
slug: brand-dorfstrasse
date: 2020-09-11T10:00:00.000Z
years:
  - "2020"
---

Beitrag von [BRK News](https://www.brknews.ch/):

> Beim Brand eines Hausanbaus am Montagmorgen (9.11.2020) in Urdorf ist grosser Sachschaden entstanden. Die Bewohner des Wohnhauses haben das Gebäude rechtzeitig verlassen können und sind unverletzt geblieben. 
>
> Gegen 9 Uhr ging über die Einsatzzentrale von Schutz & Rettung Zürich die Meldung ein, wonach an der Dorfstrasse ein Schopf brennen würde. Beim Eintreffen der Feuerwehren und der Polizei stand der an ein Einfamilienhaus angebaute Schopf in Vollbrand. Die Feuerwehr brachte das Feuer rasch unter Kontrolle und konnte das Übergreifen der Flammen auf das Wohnhaus verhindern. Die Bewohner der Liegenschaft wurden zur Sicherheit evakuiert und vor Ort betreut. Verletzt wurde niemand. Zwei Kaninchen welche sich im Schopf in einem Hasenstall befanden, konnten gerettet und an einen geeigneten Platz gebracht werden. 
>
> Die Brandursache ist zum jetzigen Zeitpunkt noch unklar und wird durch den Brandermittlungsdienst der Kantonspolizei Zürich abgeklärt. Der Schaden am Gebäude dürfte hunderttausend Franken übersteigen. 
>
> Neben der Kantonspolizei Zürich standen die Stützpunktfeuerwehr Dietikon und die Ortsfeuerwehr Urdorf, eine Patrouille der Stadtpolizei Dietikon sowie vorsorglich der Rettungsdienst des Spitals Limmattal im Einsatz. 

{{< youtube eAoyYzDZ0VU >}}
