---
title: "berita"
description: "Einsätze"
slug: "berita"
sections:
  - template: page-header-section
    enable: true
    title: "Einsätze"
    image_bg: "assets/images/news-section-1-bg.png"
    image: "assets/images/home-section-1-hotline.png"
  - template: mission-slider-section
    enable: true
    years:
      - "2024"
      - "2023"
      - "2022"
layout: page-builder
---
