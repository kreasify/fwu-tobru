---
title: "Einsätze"
description: "Einsätze"
slug: "einsatze"
sections:
  - template: page-header-section
    enable: true
    title: "Einsätze"
    image_bg: "assets/images/news-section-1-bg.png"
    image: "assets/images/home-section-1-hotline.png"
  - template: mission-slider-section
    enable: true
layout: page-builder
---
