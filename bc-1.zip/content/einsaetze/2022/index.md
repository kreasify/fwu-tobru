---
title: 2022
description: 2022
image_bg: "assets/images/news-section-1-bg.png"
mission:
  - title: Unklare Rauchentwicklung
    description: Unklare Rauchentwicklung
    date: 26. December 2022 23:09
    number: 2022|68
    street: Im Bänz 2, 8902 Urdorf
    group: BAG N2
  - title: SPA autom. Alarm
    description: SPA autom. Alarm
    date: 23. December 2022 04:59
    number: 2022|67
    street: Heinrich-Stutz-Strasse 27, 8902 Urdorf
    group: KA N2
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 21. December 2022 11:16
    number: 2022|66
    street: Im Stüdacker 20, 8902 Urdorf
    group: TK,BAG T1
  - title: Verkehrsregelung
    description: Verkehrsregelung
    date: 19. December 2022 17:56
    number: 2022|65
    street: Kreuzung Birmensdorferstrasse / 1, 8902 Urdorf
    group: TK,Vrk-Gr
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 17. December 2022 13:34
    number: 2022|64
    street: In der Breiti 6, 8902 Urdorf
    group: BAG N1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 13. December 2022 16:00
    number: 2022|63
    street: Im Hackacker 15, 8902 Urdorf
    group: KA T1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 12. December 2022 09:56
    number: 2022|62
    street: Im Geren 5, 8902 Urdorf
    group: TK,BAG T1
  - title: Kleintier
    description: Kleintier
    date: 11. December 2022 14:33
    number: 2022|61
    street: Kleibersmättelistrasse, 8902 Urdorf
    group: TK
  - title: Kleintier
    description: Kleintier
    date: 10. December 2022 16:08
    number: 2022|60
    street: 8902 Urdorf nahe (ca. 36m Kleibersmättelistrasse)
    group: TK
  - title: Vollbrand Gebäude
    description: Vollbrand Gebäude
    date: 29. November 2022 22:27
    number: 2022|59
    street: Risistrasse 4, 8903 Birmensdorf ZH
    group: ADL
  - title: Patientenrettung ADL/HRF
    description: Patientenrettung ADL/HRF
    date: 26. November 2022 01:53
    number: 2022|58
    street: Zürcherstrasse 13, 8903 Birmensdorf ZH
    group: ADL
  - title: Brand LKW/Bus/Car
    description: Brand LKW/Bus/Car
    date: 22. November 2022 06:22
    number: 2022|57
    street: Bushaltestelle Niederurdorf, 8902 Urdorf
    group: KA T1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 13. November 2022 00:58
    number: 2022|56
    street: Steinackerstrasse 38, 8902 Urdorf
    group: TK,BAG N4
  - title: Eingeschl. Person Lift
    description: Eingeschl. Person Lift
    date: 07. November 2022 09:10
    number: 2022|55
    street: Feldstrasse 13, 8902 Urdorf
    group: TK,BAG T1
  - title: Oelspur
    description: Oelspur
    date: 05. November 2022 08:32
    number: 2022|54
    street: Neumattstrasse 13, 8902 Urdorf
    group: BAG N3
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 22. October 2022 05:19
    number: 2022|53
    street: Weihermattstrasse 6, 8902 Urdorf
    group: TK,BAG N2
  - title: Wasserrohrbruch Strasse
    description: Wasserrohrbruch Strasse
    date: 20. October 2022 23:13
    number: 2022|52
    street: Schönheimstrasse 3, 8902 Urdorf
    group: BAG N1
  - title: Gelöschter Brand
    description: Gelöschter Brand
    date: 20. October 2022 13:58
    number: 2022|51
    street: Mühlegasse 3, 8902 Urdorf
    group: BAG T1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 11. October 2022 14:01
    number: 2022|50
    street: Schulstrasse 7, 8902 Urdorf
    group: TK
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 03. October 2022 19:58
    number: 2022|49
    street: Im Spitzler 17, 8902 Urdorf
    group: BAG N4
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 29. September 2022 14:06
    number: 2022|48
    street: Schlierenstrasse 50, 8902 Urdorf
    group: TK
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 22. September 2022 23:14
    number: 2022|47
    street: Bodenfeldstrasse 23, 8902 Urdorf
    group: TK
  - title: Austr Treibstoff/Heizoel Kanal/Gewässer betr.
    description: Austr Treibstoff/Heizoel Kanal/Gewässer betr.
    date: 22. September 2022 11:17
    number: 2022|46
    street: Steinackerstrasse 48, 8902 Urdorf
    group: BAG T1
  - title: Kleintier
    description: Kleintier
    date: 21. September 2022 09:31
    number: 2022|45
    street: Sonnhaldenstrasse 4, 8902 Urdorf
    group: TK
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 15. September 2022 06:26
    number: 2022|44
    street: Weihermattstrasse 44, 8902 Urdorf
    group: KA T1
  - title: BMA telefon. Alarm
    description: BMA telefon. Alarm
    date: 06. September 2022 06:12
    number: 2022|43
    street: Foitek Birmensdorferstrasse 28, 8902 Urdorf
    group: KA T1
  - title: Brand im MFH
    description: Brand im MFH
    date: 04. September 2022 02:49
    number: 2022|42
    street: In der Fadmatt 17, 8902 Urdorf
    group: ADL,KA N1
  - title: Unklare Rauchentwicklung
    description: Unklare Rauchentwicklung
    date: 02. September 2022 17:57
    number: 2022|41
    street: In der Luberzen 42, 8902 Urdorf
    group: BAG T1
  - title: Wasserrohrbruch Strasse
    description: Wasserrohrbruch Strasse
    date: 31. August 2022 22:08
    number: 2022|40
    street: Uetlibergstrasse 84, 8902 Urdorf
    group: ""
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 31. August 2022 21:42
    number: 2022|39
    street: In der Weid 6, 8902 Urdorf
    group: BAG N3
  - title: Wasserrohrbruch Strasse
    description: Wasserrohrbruch Strasse
    date: 31. August 2022 19:37
    number: 2022|38
    street: Weihermattstrasse 76.3, 8902 Urdorf
    group: BAG N2
  - title: Bergung/Sicherung v. Sachgütern (Unwetter)
    description: Bergung/Sicherung v. Sachgütern (Unwetter)
    date: 20. July 2022 18:55
    number: 2022|37
    street: 8902 Urdorf nahe (ca. 4m In der Luberzen 1)
    group: BAG N1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 20. July 2022 13:25
    number: 2022|36
    street: In der Gyrhalden 12, 8902 Urdorf
    group: TK,BAG T1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 19. July 2022 12:50
    number: 2022|35
    street: In der Luberzen 2, 8902 Urdorf
    group: KA T1
  - title: Brand im MFH
    description: Brand im MFH
    date: 11. July 2022 22:34
    number: 2022|34
    street: Birmensdorferstrasse 89, 8902 Urdorf
    group: ADL,KA N2
  - title: Austr Oel/Treibstoff/Heizoel
    description: Austr Oel/Treibstoff/Heizoel
    date: 08. July 2022 22:01
    number: 2022|33
    street: Bergermoosstrasse 4.1, 8902 Urdorf
    group: TK
  - title: Brand im MFH
    description: Brand im MFH
    date: 07. July 2022 06:05
    number: 2022|32
    street: Zürcherstrasse 110, 8903 Birmensdorf ZH
    group: ADL
  - title: Eingekl. Person PW
    description: Eingekl. Person PW
    date: 30. June 2022 08:57
    number: 2022|31
    street: Kreuzung Im Spitzler / Birmensdorferstrasse, 8902 Urdorf
    group: KA T1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 30. June 2022 03:55
    number: 2022|30
    street: Dorfstrasse 18, 8902 Urdorf
    group: TK
  - title: SPA autom. Alarm
    description: SPA autom. Alarm
    date: 25. June 2022 08:16
    number: 2022|29
    street: Birmensdorferstrasse 87, 8902 Urdorf
    group: KA N1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 21. June 2022 18:58
    number: 2022|28
    street: In der Halden 15, 8902 Urdorf
    group: BAG N4
  - title: Patientenbergung ADL/HRF
    description: Patientenbergung ADL/HRF
    date: 18. June 2022 21:39
    number: 2022|27
    street: In der Breiti 10, 8902 Urdorf
    group: ADL
  - title: Erkundung / unklare Situation
    description: Erkundung / unklare Situation
    date: 16. June 2022 21:56
    number: 2022|26
    street: Werkhofstrasse 7, 8902 Urdorf
    group: TK
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 15. June 2022 19:37
    number: 2022|25
    street: Uetlibergstrasse 38, 8902 Urdorf
    group: TK
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 07. June 2022 13:30
    number: 2022|24
    street: Heinrich-Stutz-Strasse 20, 8902 Urdorf
    group: KA T1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 27. May 2022 10:24
    number: 2022|23
    street: In der Gyrhalden 14, 8902 Urdorf
    group: TK
  - title: Kleintier
    description: Kleintier
    date: 19. May 2022 17:54
    number: 2022|22
    street: Bergstrasse 18, 8902 Urdorf
    group: TK
  - title: Brand unbew. Gebäude
    description: Brand unbew. Gebäude
    date: 18. May 2022 22:55
    number: 2022|21
    street: Waldhütte Aesch Lielistrasse 50, 8904 Aesch ZH
    group: ADL
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 19. April 2022 19:57
    number: 2022|20
    street: Krummackerstrasse 6, 8902 Urdorf
    group: TK
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 17. April 2022 19:10
    number: 2022|19
    street: Schulstrasse 33, 8902 Urdorf
    group: TK
  - title: Eingekl. Person PW
    description: Eingekl. Person PW
    date: 09. April 2022 03:22
    number: 2022|18
    street: Kreuzung Schützenstrasse / Birmensdorferstrasse, 8902 Urdorf
    group: KA N2
  - title: Brand im Industrie-/Lagergeb
    description: Brand im Industrie-/Lagergeb
    date: 07. April 2022 21:45
    number: 2022|17
    street: Eidg. Forschungsanstalt WSL Zürcherstrasse 111, 8903 Birmensdorf ZH
    group: ADL
  - title: Oelspur
    description: Oelspur
    date: 06. April 2022 10:38
    number: 2022|16
    street: Kreuzung Bodenfeldstrasse / Neumattstrasse, 8902 Urdorf
    group: BAG T1
  - title: Brand im Spezgeb.
    description: Brand im Spezgeb.
    date: 03. April 2022 17:47
    number: 2022|15
    street: Mehrzweckgebäude Zentrum Birmensdorferstrasse 77, 8902 Urdorf
    group: ADL,KA N1,KA N2
  - title: Austr Oel/Treibstoff/Heizoel
    description: Austr Oel/Treibstoff/Heizoel
    date: 26. March 2022 18:56
    number: 2022|14
    street: Bodenfeldstrasse 27, 8902 Urdorf
    group: BAG N3
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 17. March 2022 13:53
    number: 2022|13
    street: Schüracher 2, 8902 Urdorf
    group: TK,BAG T1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 13. March 2022 19:13
    number: 2022|12
    street: In der Luberzen 5, 8902 Urdorf
    group: BAG N2
  - title: Brand im MFH
    description: Brand im MFH
    date: 01. March 2022 22:26
    number: 2022|11
    street: Kreuzung Zürcherstrasse / Lettenmattstrasse, 8903 Birmensdorf ZH
    group: ADL
  - title: Oelspur
    description: Oelspur
    date: 28. February 2022 14:27
    number: 2022|10
    street: Bodenfeldstrasse 21, 8902 Urdorf
    group: TK
  - title: Austr Treibstoff/Heizoel Kanal/Gewässer betr.
    description: Austr Treibstoff/Heizoel Kanal/Gewässer betr.
    date: 15. February 2022 17:51
    number: 2022|9
    street: Bodenfeldstrasse 5, 8902 Urdorf
    group: BAG T1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 13. February 2022 09:28
    number: 2022|8
    street: Im Moos 13, 8902 Urdorf
    group: BAG N1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 08. February 2022 21:01
    number: 2022|7
    street: Im Stüdacker 7, 8902 Urdorf
    group: TK
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 07. February 2022 18:39
    number: 2022|6
    street: Birmensdorferstrasse 87
    group: KA N1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 05. February 2022 22:35
    number: 2022|5
    street: In der Rebhalden 13
    group: TK
  - title: Patientenbergung ADL/HRF
    description: Patientenbergung ADL/HRF
    date: 01. February 2022 16:58
    number: 2022|4
    street: In der Fadmatt 37
    group: ADL
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 27. January 2022 18:22
    number: 2022|3
    street: Im Hackacker 15
    group: KA N2
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 26. January 2022 17:58
    number: 2022|2
    street: Krummackerstrasse 22
    group: TK
  - title: Brand Cont./Mulde/Abfall
    description: Brand Cont./Mulde/Abfall
    date: 01. January 2022 00:46
    number: 2022|1
    street: Uitikonerstrasse
    group: BAG N4
---