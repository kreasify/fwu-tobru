---
title: 2023
description: 2023
image_bg: "assets/images/news-section-1-bg.png"
mission:
  - title: Brand Haufen/Baum/Gebüsch
    description: Brand Haufen/Baum/Gebüsch
    date: 29. December 2023 18:19
    number: 2023|78
    street: Konditorei Lehmann Birmensdorferstrasse 137, 8902 Urdorf
    group: BAG N2
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 21. December 2023 09:24
    number: 2023|77
    street: Bahnhofstrasse 91, 8902 Urdorf
    group: TK
  - title: Wasserrohrbruch Strasse
    description: Wasserrohrbruch Strasse
    date: 14. December 2023 02:23
    number: 2023|76
    street: 8902 Urdorf
    group: TK
  - title: SPA autom. Alarm
    description: SPA autom. Alarm
    date: 11. December 2023 19:25
    number: 2023|75
    street: Heinrich-Stutz-Strasse 27, 8902 Urdorf
    group: KA N2
  - title: Brand im Industrie-/Lagergeb
    description: Brand im Industrie-/Lagergeb
    date: 06. December 2023 15:41
    number: 2023|74
    street: Schützenstrasse 33, 8902 Urdorf
    group: KA T1
  - title: Baum/Ast (Unwetter)
    description: Baum/Ast (Unwetter)
    date: 02. December 2023 11:02
    number: 2023|73
    street: Im Spitzler, 8902 Urdorf
    group: ""
  - title: SPA autom. Alarm
    description: SPA autom. Alarm
    date: 02. December 2023 10:58
    number: 2023|72
    street: Birmensdorferstrasse 87, 8902 Urdorf
    group: ""
  - title: Baum/Ast (Unwetter)
    description: Baum/Ast (Unwetter)
    date: 02. December 2023 10:49
    number: 2023|71
    street: In der Breiti 6, 8902 Urdorf
    group: BAG N1
  - title: Bergung/Sicherung v. Sachgütern
    description: Bergung/Sicherung v. Sachgütern
    date: 30. November 2023 11:09
    number: 2023|70
    street: Kreuzung Hegiweg / Uitikonerstrasse, 8902 Urdorf
    group: TK,BAG T1
  - title: Bergung/Sicherung v. Sachgütern
    description: Bergung/Sicherung v. Sachgütern
    date: 29. November 2023 08:56
    number: 2023|69
    street: Grubenstrasse 4, 8902 Urdorf
    group: KA T1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 27. November 2023 00:10
    number: 2023|68
    street: Bergermoosstrasse 4, 8902 Urdorf
    group: KA N1
  - title: Baum/Ast (Unwetter)
    description: Baum/Ast (Unwetter)
    date: 16. November 2023 22:56
    number: 2023|67
    street: Kreuzung Hegiweg / Uitikonerstrasse, 8902 Urdorf
    group: BAG N4
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 13. November 2023 16:48
    number: 2023|66
    street: Untermatt 23, 8902 Urdorf
    group: TK
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 07. November 2023 18:03
    number: 2023|65
    street: Werkhofstrasse 337, 8902 Urdorf
    group: KA N2
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 03. November 2023 22:07
    number: 2023|64
    street: Birmensdorferstrasse 87, 8902 Urdorf
    group: KA N1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 27. October 2023 06:35
    number: 2023|63
    street: Birmensdorferstrasse 87, 8902 Urdorf
    group: KA T1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 11. October 2023 20:53
    number: 2023|62
    street: Im Spitzler 17, 8902 Urdorf
    group: BAG N3
  - title: Brand Cont./Mulde/Abfall
    description: Brand Cont./Mulde/Abfall
    date: 10. October 2023 17:30
    number: 2023|61
    street: Bushaltestelle Sonne Birmensdorferstrasse 122, 8902 Urdorf
    group: BAG T1
  - title: SPA autom. Alarm
    description: SPA autom. Alarm
    date: 06. October 2023 14:08
    number: 2023|60
    street: Heinrich-Stutz-Strasse 20, 8902 Urdorf
    group: KA T1
  - title: Austr Treibstoff/Heizoel Kanal/Gewässer betr.
    description: Austr Treibstoff/Heizoel Kanal/Gewässer betr.
    date: 29. September 2023 11:37
    number: 2023|59
    street: Schlierenstrasse 27, 8902 Urdorf
    group: BAG T1
  - title: Brand Cont./Mulde/Abfall
    description: Brand Cont./Mulde/Abfall
    date: 16. September 2023 00:18
    number: 2023|58
    street: Bergstrasse, 8902 Urdorf
    group: BAG N2
  - title: Oelspur
    description: Oelspur
    date: 13. September 2023 15:01
    number: 2023|57
    street: Schützenstrasse, 8902 Urdorf
    group: TK
  - title: Kleintier
    description: Kleintier
    date: 09. September 2023 18:00
    number: 2023|56
    street: Kirchgasse 21, 8902 Urdorf
    group: TK
  - title: AWEL
    description: AWEL
    date: 31. August 2023 17:05
    number: 2023|55
    street: Bachstrasse 19b, 8902 Urdorf
    group: TK
  - title: Gefahrgut chemisch mit Brand
    description: Gefahrgut chemisch mit Brand
    date: 31. August 2023 06:46
    number: 2023|54
    street: In der Luberzen 2, 8902 Urdorf
    group: KA T1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 28. August 2023 20:34
    number: 2023|53
    street: Im Embri 15, 8902 Urdorf
    group: TK
  - title: Wasserrohrbruch Strasse
    description: Wasserrohrbruch Strasse
    date: 22. August 2023 17:08
    number: 2023|52
    street: Haus 11 - Personalhaus Wissenfluestrasse 10, 8902 Urdorf
    group: BAG T1
  - title: Gelöschter Brand
    description: Gelöschter Brand
    date: 14. August 2023 00:19
    number: 2023|51
    street: In der Breiti 6, 8902 Urdorf
    group: BAG N1
  - title: Bergung/Sicherung v. Sachgütern
    description: Bergung/Sicherung v. Sachgütern
    date: 02. August 2023 20:12
    number: 2023|50
    street: In der Luberzen 25, 8902 Urdorf
    group: BAG N4
  - title: Baum/Ast (Unwetter)
    description: Baum/Ast (Unwetter)
    date: 24. July 2023 13:15
    number: 2023|49
    street: Kreuzung Heinrich-Stutz-Strasse / Schützenstrasse, 8902 Urdorf
    group: ""
  - title: Überschwemmung (Unwetter)
    description: Überschwemmung (Unwetter)
    date: 24. July 2023 13:07
    number: 2023|48
    street: Im Grüt 2, 8902 Urdorf
    group: BAG T1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 19. July 2023 14:46
    number: 2023|47
    street: Uitikonerstrasse 22, 8902 Urdorf
    group: TK,BAG T1
  - title: BMA telefon. Alarm
    description: BMA telefon. Alarm
    date: 19. July 2023 12:16
    number: 2023|46
    street: Foitek Birmensdorferstrasse 28, 8902 Urdorf
    group: KA T1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 26. June 2023 12:27
    number: 2023|45
    street: Grossmattstrasse 9, 8902 Urdorf
    group: KA T1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 25. June 2023 06:40
    number: 2023|44
    street: Heinrich-Stutz-Strasse 27, 8902 Urdorf
    group: KA N2
  - title: Oelspur
    description: Oelspur
    date: 22. June 2023 20:39
    number: 2023|43
    street: Birmensdorferstrasse 135, 8902 Urdorf
    group: TK
  - title: Oelspur
    description: Oelspur
    date: 19. June 2023 22:51
    number: 2023|42
    street: Schwanen Birmensdorferstrasse 37, 8902 Urdorf
    group: TK,BAG N3
  - title: BMA telefon. Alarm
    description: BMA telefon. Alarm
    date: 15. June 2023 12:04
    number: 2023|41
    street: Steinackerstrasse 47, 8902 Urdorf
    group: KA T1
  - title: Unklare Rauchentwicklung
    description: Unklare Rauchentwicklung
    date: 15. June 2023 09:51
    number: 2023|40
    street: In der Luberzen 29, 8902 Urdorf
    group: TK,BAG T1
  - title: Austr Oel/Treibstoff/Heizoel
    description: Austr Oel/Treibstoff/Heizoel
    date: 14. June 2023 10:15
    number: 2023|39
    street: Feldstrasse 63, 8902 Urdorf
    group: TK
  - title: Wasserrohrbruch Strasse
    description: Wasserrohrbruch Strasse
    date: 12. June 2023 08:16
    number: 2023|38
    street: Kreuzung Sonnhaldenstrasse, 8902 Urdorf
    group: BAG T1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 11. June 2023 11:37
    number: 2023|37
    street: In der Rebhalden 3, 8902 Urdorf
    group: TK,BAG N2
  - title: Brand Haufen/Baum/Gebüsch
    description: Brand Haufen/Baum/Gebüsch
    date: 08. June 2023 06:22
    number: 2023|36
    street: 8902 Urdorf nahe (ca. 28m Stigelmattstrasse)
    group: BAG T1
  - title: SPA autom. Alarm
    description: SPA autom. Alarm
    date: 01. June 2023 06:39
    number: 2023|35
    street: Birmensdorferstrasse 87, 8902 Urdorf
    group: KA T1
  - title: Brand im MFH
    description: Brand im MFH
    date: 22. May 2023 08:54
    number: 2023|34
    street: Baumgartenstrasse 16, 8902 Urdorf
    group: KA T1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 03. May 2023 09:31
    number: 2023|33
    street: Birmensdorferstrasse 14, 8902 Urdorf
    group: TK,BAG T1
  - title: Gasaustritt im Gebäude
    description: Gasaustritt im Gebäude
    date: 01. May 2023 06:17
    number: 2023|32
    street: In der Fadmatt 48, 8902 Urdorf
    group: KA T1
  - title: Brand im EFH
    description: Brand im EFH
    date: 27. April 2023 15:43
    number: 2023|31
    street: Sonnhaldenstrasse 29, 8902 Urdorf
    group: KA T1
  - title: Gewässerverschmutzung
    description: Gewässerverschmutzung
    date: 12. April 2023 14:45
    number: 2023|30
    street: Schäflibach, 8902 Urdorf
    group: ""
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 08. April 2023 16:50
    number: 2023|29
    street: Neumattstrasse 33, 8902 Urdorf
    group: TK
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 06. April 2023 11:33
    number: 2023|28
    street: Dorfstrasse 33f, 8902 Urdorf
    group: TK
  - title: Brand Cont./Mulde/Abfall
    description: Brand Cont./Mulde/Abfall
    date: 04. April 2023 23:35
    number: 2023|27
    street: Werkhofstrasse 337, 8902 Urdorf
    group: BAG N1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 26. March 2023 19:29
    number: 2023|26
    street: Birmensdorferstrasse 102, 8902 Urdorf
    group: KA N1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 20. March 2023 13:37
    number: 2023|25
    street: Dorfstrasse 28i, 8902 Urdorf
    group: TK
  - title: Oelspur
    description: Oelspur
    date: 17. March 2023 10:32
    number: 2023|24
    street: Steinackerstrasse 48, 8902 Urdorf
    group: TK
  - title: Gewässerverschmutzung
    description: Gewässerverschmutzung
    date: 13. March 2023 18:41
    number: 2023|23
    street: Kreuzung Heinrich-Stutz-Strasse / Birmensdorferstrasse, 8902 Urdorf
    group: TK
  - title: Gewässerverschmutzung
    description: Gewässerverschmutzung
    date: 13. March 2023 17:29
    number: 2023|22
    street: Kreuzung Bachstrasse / Bollweg, 8902 Urdorf
    group: BAG T1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 13. March 2023 00:19
    number: 2023|21
    street: Dorfstrasse 33c, 8902 Urdorf
    group: TK
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 12. March 2023 09:16
    number: 2023|20
    street: Feldstrasse 47, 8902 Urdorf
    group: TK
  - title: Austr Oel/Treibstoff/Heizoel
    description: Austr Oel/Treibstoff/Heizoel
    date: 10. March 2023 18:03
    number: 2023|19
    street: Bergermoosstrasse 4, 8902 Urdorf
    group: TK
  - title: Unklare Rauchentwicklung
    description: Unklare Rauchentwicklung
    date: 06. March 2023 20:39
    number: 2023|18
    street: Kreuzung Schützenstrasse / Birmensdorferstrasse, 8902 Urdorf
    group: BAG N4
  - title: SPA autom. Alarm
    description: SPA autom. Alarm
    date: 02. March 2023 08:13
    number: 2023|17
    street: Heinrich-Stutz-Strasse 20, 8902 Urdorf
    group: KA T1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 01. March 2023 09:11
    number: 2023|16
    street: Keimlerweg 9, 8902 Urdorf
    group: TK,BAG T1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 01. March 2023 00:13
    number: 2023|15
    street: Werkhofstrasse 337, 8902 Urdorf
    group: KA N2
  - title: Austr Oel/Treibstoff/Heizoel
    description: Austr Oel/Treibstoff/Heizoel
    date: 26. February 2023 15:41
    number: 2023|14
    street: Bernstrasse, 8902 Urdorf
    group: TK
  - title: Oelspur
    description: Oelspur
    date: 24. February 2023 18:21
    number: 2023|13
    street: Steinerhof Bachstrasse 4, 8902 Urdorf
    group: TK
  - title: Verkehrsregelung
    description: Verkehrsregelung
    date: 23. February 2023 19:29
    number: 2023|12
    street: Kreuzung Birmensdorferstrasse / 1, 8902 Urdorf
    group: Vrk-Gr,KA N1
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 11. February 2023 14:20
    number: 2023|11
    street: Uitikonerstrasse 22, 8902 Urdorf
    group: TK,BAG N3
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 09. February 2023 17:48
    number: 2023|10
    street: Feldstrasse 63, 8902 Urdorf
    group: TK
  - title: Unklare Rauchentwicklung
    description: Unklare Rauchentwicklung
    date: 04. February 2023 21:48
    number: 2023|9
    street: Birmensdorferstrasse 71, 8902 Urdorf
    group: BAG N2
  - title: Brand Cont./Mulde/Abfall
    description: Brand Cont./Mulde/Abfall
    date: 27. January 2023 11:05
    number: 2023|8
    street: Bahnhof Weihermatt Uitikonerstrasse 50.1, 8902 Urdorf
    group: BAG T1
  - title: Partnerorganisation
    description: Partnerorganisation
    date: 25. January 2023 12:05
    number: 2023|7
    street: Birmensdorferstrasse 39a, 8902 Urdorf
    group: TK
  - title: Brand im MFH
    description: Brand im MFH
    date: 19. January 2023 04:13
    number: 2023|6
    street: Luzernerstrasse 2, 8903 Birmensdorf ZH
    group: ADL
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 09. January 2023 07:49
    number: 2023|5
    street: Heinrich-Stutz-Strasse 20, 8902 Urdorf
    group: KA T1
  - title: Austr Oel/Treibstoff/Heizoel
    description: Austr Oel/Treibstoff/Heizoel
    date: 07. January 2023 01:46
    number: 2023|4
    street: Bushaltestelle Heinrich-Stutz-Strasse, 8902 Urdorf
    group: TK,Vrk-Gr,BAG N1
  - title: Gelöschter Brand
    description: Gelöschter Brand
    date: 01. January 2023 05:44
    number: 2023|3
    street: Feldstrasse 53, 8902 Urdorf
    group: BAG N4
  - title: Brand Cont./Mulde/Abfall
    description: Brand Cont./Mulde/Abfall
    date: 01. January 2023 02:49
    number: 2023|2
    street: Parkplatz Zwischenbächen, 8902 Urdorf
    group: TK
  - title: Brand Haufen/Baum/Gebüsch
    description: Brand Haufen/Baum/Gebüsch
    date: 01. January 2023 01:45
    number: 2023|1
    street: Parkplatz Zwischenbächen, 8902 Urdorf
    group: BAG N3
---