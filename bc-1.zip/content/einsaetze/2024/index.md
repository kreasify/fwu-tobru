---
title: 2024
description: 2024
image_bg: "assets/images/news-section-1-bg.png"
mission:
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 06. August 2024 20:32
    number: 2024|38
    street: Birmensdorferstrasse 104, 8902 Urdorf
    group: TK
  - title: Brand Haufen/Baum/Gebüsch
    description: Brand Haufen/Baum/Gebüsch
    date: 03. August 2024 21:36
    number: 2024|37
    street: 47380072,8434871, 8902 Urdorf
    group: BAG N3
  - title: Brand im MFH
    description: Brand im MFH
    date: 02. August 2024 21:31
    number: 2024|36
    street: Im Geren 3, 8902 Urdorf
    group: KA N2
  - title: Erkundung / unklare Situation
    description: Erkundung / unklare Situation
    date: 01. August 2024 23:12
    number: 2024|35
    street: Mörenhof 2, 8902 Urdorf
    group: TK
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 01. August 2024 08:27
    number: 2024|34
    street: Schwarzwaldstrasse 3, 8902 Urdorf
    group: TK,BAG T1
  - title: Oelspur
    description: Oelspur
    date: 27. July 2024 20:30
    number: 2024|33
    street: Birmensdorferstrasse, 8902 Urdorf
    group: TK
  - title: Verkehrsregelung
    description: Verkehrsregelung
    date: 26. July 2024 09:28
    number: 2024|32
    street: Steinackerstrasse 31c, 8902 Urdorf
    group: Vrk-Gr
  - title: Unklare Rauchentwicklung
    description: Unklare Rauchentwicklung
    date: 24. July 2024 13:40
    number: 2024|31
    street: Foitek Birmensdorferstrasse 28, 8902 Urdorf
    group: BAG T1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 20. July 2024 11:24
    number: 2024|30
    street: Bergermoosstrasse 4, 8902 Urdorf
    group: KA N1
  - title: Flächenbrand
    description: Flächenbrand
    date: 18. July 2024 18:54
    number: 2024|29
    street: 47370709,842852, 8902 Urdorf
    group: BAG N2,KA N2
  - title: Erkundung / unklare Situation
    description: Erkundung / unklare Situation
    date: 18. July 2024 08:26
    number: 2024|28
    street: Neumattstrasse 24, 8902 Urdorf
    group: ""
  - title: Oelspur
    description: Oelspur
    date: 17. July 2024 10:11
    number: 2024|27
    street: Bahnhofstrasse 22, 8902 Urdorf
    group: TK
  - title: Traghilfe Rettungsdienst
    description: Traghilfe Rettungsdienst
    date: 16. July 2024 22:05
    number: 2024|26
    street: Weihermattstrasse 69, 8902 Urdorf
    group: TK
  - title: AWEL
    description: AWEL
    date: 16. July 2024 10:12
    number: 2024|25
    street: Im Stüdacker 4, 8902 Urdorf
    group: ""
  - title: Wasserrohrbruch Strasse
    description: Wasserrohrbruch Strasse
    date: 03. July 2024 21:01
    number: 2024|24
    street: Weihermattweg, 8902 Urdorf
    group: BAG N1
  - title: SPA autom. Alarm
    description: SPA autom. Alarm
    date: 01. July 2024 09:47
    number: 2024|23
    street: Heinrich-Stutz-Strasse 20, 8902 Urdorf
    group: KA T1
  - title: Kleintier
    description: Kleintier
    date: 25. June 2024 08:49
    number: 2024|22
    street: Bahnhofstrasse 67, 8902 Urdorf
    group: ""
  - title: Verkehrsregelung
    description: Verkehrsregelung
    date: 19. June 2024 20:36
    number: 2024|20
    street: Kreuzung Birmensdorferstrasse / Heinrich-Stutz-Strasse, 8902 Urdorf
    group: ""
  - title: Baum/Ast (Unwetter)
    description: Baum/Ast (Unwetter)
    date: 19. June 2024 20:33
    number: 2024|21
    street: Birmensdorferstrasse, 8902 Urdorf
    group: BAG N4
  - title: Kleintier
    description: Kleintier
    date: 17. June 2024 08:17
    number: 2024|19
    street: In der Luberzen 19, 8902 Urdorf
    group: TK
  - title: Kleintier
    description: Kleintier
    date: 16. June 2024 12:51
    number: 2024|18
    street: Muulaffemärt, 8902 Urdorf
    group: ""
  - title: Kleintier
    description: Kleintier
    date: 10. June 2024 21:04
    number: 2024|17
    street: Uetlibergstrasse 25, 8902 Urdorf
    group: TK
  - title: Bienen
    description: Bienen
    date: 07. June 2024 07:14
    number: 2024|16
    street: Steinackerstrasse 26, 8902 Urdorf
    group: ""
  - title: Partnerorganisation
    description: Partnerorganisation
    date: 05. June 2024 18:36
    number: 2024|15
    street: In der Fadmatt 26, 8902 Urdorf
    group: TK
  - title: Brand im EFH
    description: Brand im EFH
    date: 10. May 2024 18:47
    number: 2024|14
    street: Tannmattstrasse 39, 8902 Urdorf
    group: KA N2
  - title: Gasaustritt im Gebäude
    description: Gasaustritt im Gebäude
    date: 07. May 2024 01:57
    number: 2024|13
    street: Werkhofstrasse 7, 8902 Urdorf
    group: KA N1
  - title: Partnerorganisation
    description: Partnerorganisation
    date: 04. May 2024 09:57
    number: 2024|12
    street: Kreuzung Bergstrasse / Im Baurenacker / Wiesenweg, 8902 Urdorf
    group: TK
  - title: Baum/Ast
    description: Baum/Ast
    date: 20. April 2024 13:26
    number: 2024|11
    street: Honertstrasse, 8902 Urdorf
    group: BAG N3
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 13. April 2024 20:40
    number: 2024|10
    street: Birmensdorferstrasse 102, 8902 Urdorf
    group: KA N2
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 05. April 2024 11:43
    number: 2024|9
    street: In der Luberzen 1, 8902 Urdorf
    group: KA T1
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 21. March 2024 21:31
    number: 2024|8
    street: Werkhofstrasse 337, 8902 Urdorf
    group: KA N1
  - title: Oelspur
    description: Oelspur
    date: 20. March 2024 17:46
    number: 2024|7
    street: Kreuzung Dorfstrasse / Römergasse, 8902 Urdorf
    group: BAG T1
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 18. March 2024 11:21
    number: 2024|6
    street: Feldstrasse 59, 8902 Urdorf
    group: BAG T1
  - title: Gefahrgut biologisch
    description: Gefahrgut biologisch
    date: 09. February 2024 11:02
    number: 2024|5
    street: Logistikzentrum Urdorf Heinrich-Stutz-Strasse 27, 8902 Urdorf
    group: BAG T1
  - title: Verkehrsregelung
    description: Verkehrsregelung
    date: 02. February 2024 17:40
    number: 2024|4
    street: Birmensdorferstrasse, 8902 Urdorf
    group: Vrk-Gr
  - title: Wasser im Gebäude
    description: Wasser im Gebäude
    date: 22. January 2024 19:04
    number: 2024|3
    street: Birmensdorferstrasse 149a, 8902 Urdorf
    group: TK
  - title: BMA autom. Alarm
    description: BMA autom. Alarm
    date: 10. January 2024 10:38
    number: 2024|2
    street: Heinrich-Stutz-Strasse 27, 8902 Urdorf
    group: KA T1
  - title: Verkehrsregelung
    description: Verkehrsregelung
    date: 08. January 2024 15:23
    number: 2024|1
    street: Bushaltestelle Feldegg, 8902 Urdorf
    group: Vrk-Gr,BAG T1
---
