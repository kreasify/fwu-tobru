---
title: "Personentransporter PTF 2"
description: "Personentransporter PTF 2"
date: 2024-07-01T06:00:00+00:00
slug: "ptf2"
image_cover: "assets/images/home-vehicle-3.jpg"
specification:
    vehicle_type: "Mercedes Benz Vito"
    radio_name: "Uro PTF2"
    vintage: "2016"
    construction: "Rusterholz"
    perfomance: "100 kW"
    transmission: "Automatik"
    crew: "1 Fahrer / 1 Beifahrer / 6 Personen in Kabine"
    total_weight: "3200 Kg"
    dimensions: ""
    water_tank: "Keine"
    pump: "Keine"
draft: false
weight: 30
---