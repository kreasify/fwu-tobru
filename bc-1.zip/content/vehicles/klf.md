---
title: "Kleinlöschfahrzeug KLF"
description: "Kleinlöschfahrzeug KLF"
date: 2024-07-01T06:00:00+00:00
slug: "klf"
image_cover: "assets/images/home-vehicle-2.png"
gallery_images:
  - "assets/images/home-vehicle-1.png"
  - "assets/images/home-vehicle-2.png"
  - "assets/images/home-vehicle-3.jpg"
  - "assets/images/home-vehicle-4.png"
  - "assets/images/home-vehicle-5.png"
specification:
    vehicle_type: "Iveco Daily 65C 18D 4x4"
    radio_name: "Uro KLF"
    vintage: "2007"
    construction: "Rusterholz"
    perfomance: "130kW / 176 PS"
    transmission: "Automatik"
    crew: "1 Fahrer / 1 Beifahrer / 4 Personen in Kabine"
    total_weight: "6500 Kg"
    dimensions: "7 x 2.16 x 2.75 m"
    water_tank: "600 Liter"
    pump: Voith Turbo 60l/min bei 60bar
draft: false
weight: 20
---