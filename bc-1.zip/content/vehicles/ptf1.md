---
title: "Personentransporter PTF 1"
description: "Personentransporter PTF 1"
date: 2024-07-01T06:00:00+00:00
slug: "ptf1"
image_cover: "assets/images/home-vehicle-3.jpg"
gallery_images:
  - "assets/images/home-vehicle-1.png"
  - "assets/images/home-vehicle-2.png"
  - "assets/images/home-vehicle-3.jpg"
  - "assets/images/home-vehicle-4.png"
  - "assets/images/home-vehicle-5.png"
specification:
    vehicle_type: "Mercedes Benz 314 CDI"
    radio_name: "Uro PTF1"
    vintage: "2016"
    construction: "Rusterholz"
    perfomance: "105 kW"
    transmission: "Automatik"
    crew: "1 Fahrer / 1 Beifahrer / 6 Personen in Kabine"
    total_weight: "3500 Kg"
    dimensions: ""
    water_tank: "Keine"
    pump: "Keine"
draft: false
weight: 30
---