---
title: "Tanklöschfahrzeug TLF"
description: "Tanklöschfahrzeug TLF"
date: 2024-07-01T06:00:00+00:00
slug: "tlf"
image_cover: "assets/images/home-vehicle-1.png"
gallery_images:
  - "assets/images/home-vehicle-1.png"
  - "assets/images/home-vehicle-2.png"
  - "assets/images/home-vehicle-3.jpg"
  - "assets/images/home-vehicle-4.png"
  - "assets/images/home-vehicle-5.png"
specification:
    vehicle_type: "Iveco 190T36W Trakker"
    radio_name: "Uro TLF"
    vintage: "2009"
    construction: "Rusterholz"
    perfomance: "265kW / 360PS"
    transmission: "automatisiertes 12 Gang Schaltgetriebe"
    crew: "1 Fahrer / 1 Beifahrer / 6 Personen in Kabine"
    total_weight: "18000 kg"
    dimensions: "7.5 x 2.5 x 3.3 m"
    water_tank: "2600 litres"
    pump: |
      1x Niederdruckpumpe 3000l/min 10bar

      1x Hochdruckpumpe 400l/min 40bar
draft: false
weight: 10
---