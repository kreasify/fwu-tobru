---
title: "Verkehrsfahrzeug VKF"
description: "Verkehrsfahrzeug VKF"
date: 2024-07-01T06:00:00+00:00
slug: "vkf"
image_cover: "assets/images/home-vehicle-5.png"
gallery_images:
  - "assets/images/home-vehicle-1.png"
  - "assets/images/home-vehicle-2.png"
  - "assets/images/home-vehicle-3.jpg"
  - "assets/images/home-vehicle-4.png"
  - "assets/images/home-vehicle-5.png"
specification:
    vehicle_type: "Mercedes Benz 310"
    radio_name: "Uro VA"
    vintage: "?"
    construction: "Vogt"
    perfomance: "105 kW"
    transmission: "Automatik"
    crew: "1 Fahrer / 1 Beifahrer / 6 Personen in Kabine"
    total_weight: "3500 Kg"
    dimensions: "5.6 x 2.1 x 2.35 m"
    water_tank: "Keine"
    pump: "Keine"
draft: false
weight: 30
---